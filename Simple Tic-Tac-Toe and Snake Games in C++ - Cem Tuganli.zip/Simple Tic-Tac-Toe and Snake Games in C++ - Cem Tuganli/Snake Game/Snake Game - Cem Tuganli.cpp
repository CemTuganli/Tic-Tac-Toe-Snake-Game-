#include<iostream>
#include<conio.h>  //consol penceresinden girdi almak icin gereken fonksiyonlari kullanmak icin gerekli olan kutuphane
#include<cstdlib> //rand() rastgele sayi �reten fonksiyonlarin tanimlanabilmesi icin konulan kutuphane
#include<windows.h> // Bilgisayarin cpu'sunu yavaslatacak yani yilanin daha yavas hareket etmesini saglayacak olan Sleep() fonksiyonu icin bir kutuphane 
using namespace std;
bool gameover; 
const int genislik = 15; //harita boslugunun boyutlari belirlenir 
const int yukseklik = 15;
int x, y, meyveX, meyveY, puan=0; //yilan kafasinin, meyvenin yerini ve puan degerlerini tutan degiskenler
int kuyrukX[50], kuyrukY[50]; //YILANIN bulundugu koordinatlar
int nKuyruk;
enum eYonler 
{STOP = 0, SOL,SAG, YUKARI, ASAGI}; // Kontroller, eNum kullanildigindan artik 1 kez o yone basildiginde yilanin hareketi hep o yone dogru olur

eYonler yon; //yon bilgisini tutan degisken

void Yukleme() //oyunun baslamasi icin Yukleme() fonksiyonu cagriliyor
{
gameover = false;
yon = STOP; //biz tiklamadikca yilan hareket etmez

x = genislik / 2;
y = yukseklik / 2; //yilanin kafasi haritanin merkezinde bulunsun diye kod

meyveX = rand() % genislik; //meyvenin rastgele bi yerlerde ortaya �ikmasi icin degiskenlere rastgele deger atanir
meyveY = rand() % yukseklik; puan = 0;
}

void ciz() {
system("cls"); //sistemin temizlenmesi icin windows kodu, linux'te farklidir

for(int i = 0; i < genislik+2; i++) //harita tavani cizilir
cout << "#"; //duvar icin karakter

cout << endl ;

for (int i = 0; i < yukseklik ; i++) 
{
for (int j = 0; j < genislik; j++) 
{
if (j == 0)
cout << "#"; //duvar kisimlari icin sekil

if (i == y && j == x)
cout << "o"; // yilanin kuyrugu

else if (i == meyveY && j == meyveX )
cout << "M"; // Meyvenin M'sini koydum 
else {
bool print = false;

for (int k = 0; k< nKuyruk ; k++) 
{
if (kuyrukX [k] == j && kuyrukY [k] == i) 
{
cout << "o"; print = true;
}

}

if (!print) cout << " ";
}

if (j == genislik -1) //sag taraftaki duvar basilir
cout << "#";

}

cout << endl;

}

for (int i = 0; i< genislik+2; i++) //haritadaki bozukluklari duzeltmek icin +2 eklendi
cout << "#";

cout << endl;

cout << "Puan:" << puan << endl ; //terminale cizdigimiz haritan�n duvarinin tam altina hizalanmistir
}

void gelen ()
{

if (_kbhit ()) 
{        //kbhit "keyboard hit" yani "klavyede tusa basilinca" demektir 
switch (_getch ()) {    //switch case ile birlikte kullanilmasi gereken bir fonksiyon, "get character" demektir <conio.h> ile gelen fonksiyondur, non standard'tir

case 'a':

yon = SOL;

break;

case 'd':

yon = SAG;

break;

case 'w':

yon = YUKARI;

break;

case 's':

yon = ASAGI ;

break;

case 'x':

gameover = true;

break;

}

}

}

void isleyis()
{

int oncekiX = kuyrukX [0];  //kuyrugun hareketi icin kod, kuyrugun ilk parcasinin x kordinati icin

int oncekiY = kuyrukY [0];  //kuyrugun hareketi icin kod, kuyrugun ilk parcasinin y kordinati icin

int onceki2X, onceki2Y;

kuyrukX[0] = x;

kuyrukY[0] = y;

for(int i = 1;i < nKuyruk ; i++) 
{ //i=1'dir cunku coktan ilk kuyruk parcasinin konumu bilinmektedir

onceki2X = kuyrukX[i];  //ilk kuyruk parcasinin konumunu hatirlamak icin kod

onceki2Y = kuyrukY[i];

kuyrukX[i] = oncekiX;

kuyrukY[i] = oncekiY;

oncekiX = onceki2X;

oncekiY = onceki2Y ;

}

switch (yon) {

case SOL:

x--;

break;

case SAG:

x++;

break;

case YUKARI:

y--;

break;

case ASAGI:

y++;

break;

default:

break;

}

if (x >= genislik)               
x=0;                              
else if (x <0) x = genislik-1;   // bu if, yilanin x eksenindeki duvardan girip diger duvardan cikmasini saglamaktadir

if (y >= yukseklik) y = 0; 
else if (y < 0) y=yukseklik-1;   // bu if, yilanin y eksenindeki duvardan girip diger duvardan cikmasini saglamaktadir
/*
if(x>genislik||x<0||y>yukseklik||y>0)
gameover=true;                         yilanin kafasinin duvara carpinca diger taraftancikmak yerine, oyunun bitmesi icin yazilabilecek alternatif bi kod
*/

for (int i=0; i<nKuyruk; i++)

if (kuyrukX[i] == x && kuyrukY[i] == y)  //kuyrugun kafaya degmesi halinde oyunun bitmesi icin kod
gameover = true;

if (x == meyveX && y == meyveY) {         //kuyrugun kafaya degmesi halinde oyunun bitmesi icin kod

puan +=5;

meyveX = rand() % genislik;  //meyvenin yeri rastgele belirlenir
meyveY = rand() % yukseklik;
nKuyruk ++;

}

}

int main()
{

Yukleme();

while (!gameover) 
{
ciz();
gelen();
isleyis();
Sleep(10); // bilgisayarin cpu suna g�re yilanin hareket hizi da fazlo olur, Sleep() fonksiyonu hizin azalmasini saglar, windows.h kutuphanesi ile gelen fonksiyondur
}

return 0;
}
